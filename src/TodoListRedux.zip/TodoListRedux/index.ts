import TodoListRedux from './TodoListReduxWrapper';

export default TodoListRedux;
