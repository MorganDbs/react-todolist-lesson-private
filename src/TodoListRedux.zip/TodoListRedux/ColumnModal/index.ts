import ColumnModal from './ColumnModal';

export default ColumnModal;
